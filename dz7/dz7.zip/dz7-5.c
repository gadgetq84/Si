
#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <malloc.h>

int res_count;
int* res_array;

void fill_array(int* array,int count)
{
	for(int i=0;i<count;i++)
		scanf("%d",&array[i]);
}

void print_array(int* array,int count)
{
	for(int i=0;i<count;i++)
		printf("%d ",array[i]);
	printf("\n");
}


int getPenultimateZero(int digit)
{
	int ldig = (digit%100)/10;
	return ldig;
}

void getPzdig(int *array,int count)
{
	int cn=0;
	res_array = (int*)malloc(count * sizeof(int));
    for (int i = 0; i < count; i++)
    { 
            if (getPenultimateZero(array[i])==0)
            { 
				//printf("%d ",array[i]);
				res_array[cn]=array[i];
				cn++;
			}
    }   
	res_array = realloc(res_array,(cn-1)*sizeof(int));
	res_count = cn;
}

int main(int argc, char **argv)
{
	int arr[10];
	int size = sizeof(arr) / sizeof(arr[0]);
	setlocale( LC_ALL,"Rus" );
	printf("������� %d ����� ����� ����� ������: ",size);
	fill_array(arr,size);
	print_array(arr,size);
	getPzdig(arr,size);
	print_array(res_array,res_count);
	free(res_array);
	return 0;
}

